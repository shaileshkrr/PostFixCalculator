package com.infosys.postfixcalculator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.StringTokenizer;

public class PostFixCalculator {

	static int opr1;
	static int opr2;
	static int result;

	public static String evaluatePostFix(String input) {
		List<String> list = new ArrayList<String>();
		if (!input.isEmpty()) {
			StringTokenizer st = new StringTokenizer(input);
			while (st.hasMoreTokens()) {
				list.add(st.nextToken());
			}
		} else {
			return "Error : Empty expression";
		}
		Stack<String> tempList = new Stack<String>();
		Iterator<String> iter = list.iterator();
		while (iter.hasNext()) {
			String temp = iter.next();
			if (temp.matches("[0-9]*")) {
				tempList.push(temp);
			} else if (temp.matches("[*-/+]")) {
					
				try{
				if (temp.equals("*")) {
					opr1 = Integer.parseInt(tempList.pop());
					opr2 = Integer.parseInt(tempList.pop());
					result = opr2 * opr1;
					tempList.push("" + result);
				} else if (temp.equals("-")) {
					opr1 = Integer.parseInt(tempList.pop());
					opr2 = Integer.parseInt(tempList.pop());
					result = opr2 - opr1;
					tempList.push("" + result);
				} else if (temp.equals("/")) {
					opr1 = Integer.parseInt(tempList.pop());
					opr2 = Integer.parseInt(tempList.pop());
					result = opr2 / opr1;
					tempList.push("" + result);
				} else if (temp.equals("+")) {
					opr1 = Integer.parseInt(tempList.pop());
					opr2 = Integer.parseInt(tempList.pop());
					result = opr2 + opr1;
					tempList.push("" + result);
				}
				}catch(Exception e){
					return "Error : Invalid expression" ;
					
				}
			} else {
				return "Error : incorrect expression format , add space in between every number and operator";
			}
		}
		return tempList.pop();
	}

	public static void main(String args[]) {

		// input the postfix expression with spaces in between
		// eg: "65 3 5 * + 83 -"

		String res = PostFixCalculator.evaluatePostFix("3 + 2 + 4 4 * -");
		System.out.println(res);

	}

}
